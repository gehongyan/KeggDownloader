﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KeggParser.Utils;

namespace KeggParser
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void ParseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string url = UrlTextBox.Text;
                List<string> codeList = Utils.KeggParser.ParseLinkToCodes(url);

                List<Task<(string, string)>> tasks = codeList.Select(Utils.KeggParser.ParseCodeToSequenceNumberAsync).ToList();

                while (tasks.Any())
                {
                    Task<(string, string)> completedTask = await Task.WhenAny(tasks);
                    tasks.Remove(completedTask);

                    (string code, string seq) = await completedTask;
                    ResultTextBox.Text += $"{code},{seq}\n";
                }

                ResultTextBox.Text += "===============================\n";
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.StackTrace);
            }
            
        }

        private async void ParsePatchButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ResultTextBox.Text += "正在提取代码列表\n";
                string url = UrlTextBox.Text;
                List<PathwayStruct> list = await Utils.KeggParser.ParseCatalogAsync(url);

                List<PathwayStruct> tenMaxList =
                    list.Where(p => p.Id < 5200)
                        .OrderByDescending(p => p.Count)
                        .Take(10)
                        .ToList();

                List<string> codeList = tenMaxList
                    .SelectMany(p => Utils.KeggParser.ParseLinkToCodes(p.Url))
                    .ToList();

                int codeTotal = codeList.Count;
                ResultTextBox.Text += $"获得代码共{codeTotal}个\n";

                codeList = codeList.Distinct().ToList();
                int codeDistinct = codeList.Count;
                ResultTextBox.Text += $"代码去重共{codeDistinct}个\n";

                ResultTextBox.Text += $"正在分组拉取结果\n";

                List<List<string>> codeSeparated = new();

                int j = 10;
                for (int i = 0; i < codeList.Count; i += 10)
                {
                    List<string> cList = new();
                    cList = codeList.Take(j).Skip(i).ToList();
                    j += 10;
                    codeSeparated.Add(cList);
                }

                Dictionary<string, string> dic = new();

                for (int index = 0; index < codeSeparated.Count; index++)
                {
                    ResultTextBox.Text += $"第{index + 1}组/共{codeSeparated.Count}组\n";
                    List<Task<(string, string)>> tasks = codeSeparated[index].Select(Utils.KeggParser.ParseCodeToSequenceNumberAsync).ToList();

                    while (tasks.Any())
                    {
                        Task<(string, string)> completedTask = await Task.WhenAny(tasks);
                        tasks.Remove(completedTask);

                        try
                        {
                            (string code, string seq) = await completedTask;
                            bool succeed = dic.TryAdd(code, seq);
                            if (!succeed)
                            {
                                ResultTextBox.Text += $"向字典添加{code},{seq}失败\n";
                            }
                        }
                        catch (Exception exception)
                        {
                            ResultTextBox.Text += $"查询过程中出现错误，请在检查输出结果\n";
                            MessageBox.Show(exception.StackTrace);
                        }
                    }
                }
                ResultTextBox.Text += $"结果拉取完成，正在输出结果\n";

                foreach (PathwayStruct pathwayStruct in tenMaxList)
                {
                    ResultTextBox.Text += $"页面1：{pathwayStruct.Id} ({pathwayStruct.Url})\n";
                    ResultTextBox.Text += $"共{pathwayStruct.Count}条\n";

                    List<string> codes = Utils.KeggParser.ParseLinkToCodes(pathwayStruct.Url);

                    foreach (string code in codes)
                    {
                        if (dic.ContainsKey(code))
                        {
                            if (!string.IsNullOrWhiteSpace(dic[code]))
                            {
                                ResultTextBox.Text += $"{code},{dic[code]}\n";
                            }
                            else
                            {
                                ResultTextBox.Text += $"拉取{code}对应结果匹配空，请手动核实 https://www.kegg.jp/entry/{code}\n";
                            }
                        }
                        else
                        {
                            ResultTextBox.Text += $"拉取{code}对应结果未成功，请手动核实 https://www.kegg.jp/entry/{code}\n";
                        }
                        
                    }
                }

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.StackTrace);
            }

        }
        
    }
}
