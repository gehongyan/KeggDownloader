﻿using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HtmlAgilityPack;

namespace KeggParser.Utils
{
    public static class KeggParser
    {
        public static List<string> ParseLinkToCodes(string link)
        {
            return link.Remove(0, 88).Split('/').Distinct().ToList();
        }

        public static async Task<(string, string)> ParseCodeToSequenceNumberAsync(string code)
        {
            HtmlWeb webpage = new();
            HtmlDocument webDoc = await webpage.LoadFromWebAsync($"https://www.kegg.jp/entry/{code}");
            string docHtml = webDoc.DocumentNode.InnerText;

            Regex rgx = new(@"\[EC:((\d+\.){3}\d+)\]");
            Match result = rgx.Match(docHtml);
            string sequence = result.Groups[1].Value;
            return (code, sequence);
        }

        private static int ParseCount(string text)
        {
            Regex rgx = new Regex(@"\((\d+)\)");
            Match match = rgx.Match(text);
            string count = match.Groups[1].Value;
            return int.Parse(count);
        }

        public static async Task<List<PathwayStruct>> ParseCatalogAsync(string url)
        {
            HtmlWeb webpage = new();
            HtmlDocument webDoc = await webpage.LoadFromWebAsync(url);
            HtmlNodeCollection nodes = webDoc.DocumentNode.SelectNodes(@"//*[@id=""main""]/p/a");

            List<PathwayStruct> list = nodes.Select(n => new PathwayStruct()
            {
                Url = n.Attributes["href"].Value,
                Count = ParseCount(n.NextSibling.InnerText),
                Id = int.Parse(n.InnerText)
            }).ToList();
            return list;
        }
    }

    

    public struct PathwayStruct
    {
        public string Url;

        public int Id;

        public int Count;
    }
}